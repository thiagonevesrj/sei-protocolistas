# Arquitetura e caminhos

## Pasta oficial

`C:\Projetos\Sei-Protocolistas\sei-protocolistas`

## Arquivos principais trabalhados

### Extensão

`manifest.json`

Responsável por:

- permissões do SEI;
- permissões do OWA;
- carregamento do FAST MAIL;
- recursos acessíveis pelo OWA.

### FAST MAIL

`cs_modules\fast_mail\index.js`

Responsável por:

- identificação do operador;
- captura do remetente;
- Bcc automático;
- assunto de TRIAGEM;
- card;
- checkboxes;
- inserção do corpo do e-mail;
- gravação temporária dos dados.

`cs_modules\fast_mail\styles.css`

Responsável por:

- aparência compacta;
- card recolhível;
- card movível;
- rolagem interna;
- adaptação a telas menores.

### Catálogo

`data\catalogo-processos.json`

Responsável pelos procedimentos prioritários e unidades de destino.

## Armazenamento usado

- `fastMailOperadorValidado`
- `centralProtocolistaAtendimento`
- posição visual via `localStorage`:
  `seiProtocolistasFastMailPosition`

## Endereço do OWA

`https://venus2.detran.rj.gov.br/owa/`

## Comportamento de atualização

Sempre:

1. fechar todas as abas e janelas do OWA;
2. substituir somente o arquivo indicado;
3. abrir `chrome://extensions`;
4. recarregar o SEI Protocolistas;
5. abrir o OWA novamente.

Caso contrário, pode ocorrer:

`Extension context invalidated`

Isso não significa necessariamente erro da lógica nova; significa que uma página antiga continuou ligada ao contexto anterior da extensão.
