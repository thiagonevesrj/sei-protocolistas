# Próximos passos

## Etapa 1 — Encerrar o piloto DAF

1. revisar texto da exigência;
2. confirmar checkboxes;
3. verificar declaração de residência;
4. definir assinatura institucional;
5. testar em telas pequenas;
6. testar resposta com histórico curto e longo;
7. testar repetição acidental da exigência.

## Etapa 2 — Fase 1: Orientar documentação

Essa fase ocorre antes de “Faltam documentos”.

Uso:

- cidadão ainda não explicou o pedido;
- cidadão pediu somente orientação;
- nenhuma documentação foi analisada.

O texto deve apresentar a documentação completa e os links pertinentes.

## Etapa 3 — Documentação completa

Ação prevista:

`DOCUMENTAÇÃO COMPLETA`

Regras:

- Nome obrigatório;
- CPF obrigatório;
- procedimento obrigatório;
- preparar dados para o FAST PROC;
- não enviar automaticamente.

## Etapa 4 — Integração FAST MAIL → FAST PROC

Transferir:

- nome;
- CPF;
- e-mail;
- procedimento;
- unidade;
- operador;
- data;
- assunto;
- anexos ou referências necessárias.

## Etapa 5 — Retorno FAST PROC → FAST MAIL

Depois da abertura e remessa no SEI:

- receber número SEI;
- gerar resposta final;
- alterar `TRIAGEM` para `FECHADO`;
- manter envio manual.

## Etapa 6 — Catálogo central de formulários

Primeiros formulários:

- Requerimento Geral;
- Devolução de Taxas;
- Desistência de Categoria;
- Cancelamento de Comunicação de Venda;
- Declaração de Residência.

Cada registro deve possuir:

- identificador;
- nome oficial;
- URL;
- procedimento;
- condição de exibição;
- texto de orientação;
- data de verificação.

## Etapa 7 — Expansão dos procedimentos

Prioridades já catalogadas:

1. Devolução de Taxas — DIVAF;
2. Desistência Categoria 1ª Habilitação — SERVECH;
3. Solicitação Geral de Habilitação — DIRHAB;
4. Solicitações Gerais de Veículos — PROTDIRRV;
5. Cancelamento de Comunicação de Venda — CVDIVDCI;
6. Certidão de Identificação Civil — DIRIC;
7. Solicitação de Perícia Médica — DIVMED;
8. Isenção de Taxa — SERVECH;
9. Averbação de CNH Estrangeira — NUCNAE;
10. Elaboração de Ofício de Mero Expediente — PROTDIJUR;
11. Averiguação de Clonagem — DIVCLONE.
