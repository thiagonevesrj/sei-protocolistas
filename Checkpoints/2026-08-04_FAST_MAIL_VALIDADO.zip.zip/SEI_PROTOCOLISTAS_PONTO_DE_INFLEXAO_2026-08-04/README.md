# SEI Protocolistas — Ponto de Inflexão

**Data do checkpoint:** 04/08/2026  
**Projeto:** SEI Protocolistas  
**Responsável:** Thiago Neves  
**Pasta oficial local:** `C:\Projetos\Sei-Protocolistas\sei-protocolistas`  
**Branch de trabalho:** `desenvolvimento`

Este pacote registra o estado funcional alcançado até o momento, os arquivos que compõem o checkpoint atual, as decisões operacionais tomadas e os próximos passos. Ele foi criado para permitir:

- retomar o desenvolvimento sem depender da memória do chat;
- iniciar um novo chat com contexto completo;
- compreender o que já funciona, como foi construído e o que ainda falta;
- restaurar os arquivos principais do FAST MAIL em caso de regressão.

## Objetivo central

O SEI Protocolistas existe para reduzir o trabalho mecânico do protocolista:

> **clicar menos, digitar menos e ganhar tempo.**

Toda funcionalidade nova deve ser avaliada por esse critério. O sistema não deve criar mais etapas do que remove.

## Regra de desenvolvimento

> **Diagnosticar primeiro. Alterar depois. Nunca o contrário.**

Durante testes:

1. substituir somente os arquivos explicitamente indicados;
2. nunca substituir pastas inteiras que contenham outros módulos;
3. fechar todas as janelas do OWA antes de recarregar a extensão;
4. reabrir o OWA depois da atualização;
5. validar uma mudança por vez.

## Estado atual validado

O FAST MAIL já consegue:

- carregar somente na janela de resposta do OWA;
- permanecer oculto na caixa de entrada;
- identificar o operador autenticado, como `Protocolista 31`;
- capturar o e-mail do remetente no cabeçalho atual;
- preparar automaticamente o Bcc fixo:
  `protocolodetran@detran.rj.gov.br`;
- funcionar sem exibir botão ou status visual do Bcc;
- apresentar um card compacto;
- recolher e expandir o card;
- mover o card pela barra superior;
- salvar a posição do card no navegador;
- manter rolagem interna em telas menores;
- carregar o catálogo de procedimentos prioritários;
- permitir CPF opcional no FAST MAIL;
- tornar o CPF obrigatório apenas na futura migração para o FAST PROC;
- preparar assunto de TRIAGEM;
- criar TRIAGEM sem procedimento usando `UNDEFINED`;
- substituir `UNDEFINED` pela unidade correta posteriormente;
- preservar nome, data, número do protocolista e status da TRIAGEM;
- executar o piloto:
  `Devolução de Taxas → Faltam documentos`;
- marcar documentos faltantes por checkbox;
- inserir uma exigência profissional no topo do corpo;
- preservar o histórico antigo;
- inserir o divisor:
  `----- HISTÓRICO DE MENSAGENS ANTERIORES -----`;
- incluir o link do formulário apenas quando o checkbox correspondente for marcado.

## Regra do assunto

### Procedimento ainda desconhecido

`NOME - UNDEFINED - DDMMAAAANºPROTOCOLISTA - TRIAGEM`

Exemplo:

`LUCIANA ALVES - UNDEFINED - 0408202631 - TRIAGEM`

### Procedimento identificado depois

O FAST MAIL substitui somente:

`UNDEFINED → DIVAF`

Resultado:

`LUCIANA ALVES - DIVAF - 0408202631 - TRIAGEM`

A data e o número do protocolista originais permanecem.

## Fluxo piloto validado

### Devolução de Taxas — Faltam documentos

Checkboxes atuais:

- Formulário de Devolução de Taxas;
- Documento de identificação;
- CPF;
- Comprovante de residência;
- DUDA ou GRT;
- Comprovante de pagamento;
- Comprovante bancário.

Links atuais:

- Formulário de Devolução de Taxas:
  `https://www.detran.rj.gov.br/images/formularios/DA0032_devolutaxa.pdf`
- Declaração de Residência:
  `https://www.detran.rj.gov.br/images/formularios/DETRAN0034_declararesid.pdf`

Os links entram somente quando o item correspondente é marcado.

## Arquivos do checkpoint

Dentro de `snapshot_atual`:

- `manifest.json`
- `cs_modules/fast_mail/index.js`
- `cs_modules/fast_mail/styles.css`
- `data/catalogo-processos.json`

Esses arquivos representam o estado funcional validado no encerramento deste chat.

## Atenção sobre o manifest

O bloco `web_accessible_resources` deve usar:

`https://venus2.detran.rj.gov.br/*`

O Chrome rejeitou o padrão com `/owa/*` nesse bloco.

O content script do FAST MAIL continua restrito ao OWA:

`https://venus2.detran.rj.gov.br/owa/*`

## O que ainda não está concluído

- inclusão da logo nova no cabeçalho do card;
- revisão editorial final do texto de exigência;
- conferência definitiva dos documentos exigidos na Devolução de Taxas;
- Fase 1 — Orientar documentação;
- Documentação completa;
- migração dos dados para o FAST PROC;
- retorno do número SEI ao FAST MAIL;
- resposta final de processo aberto;
- mudança de `TRIAGEM` para `FECHADO`;
- catálogo central de formulários;
- outros procedimentos;
- ofícios de mero expediente;
- exceções e desdobramentos específicos;
- commit e push do checkpoint para o GitHub.

## Próxima decisão funcional

Finalizar completamente:

`Devolução de Taxas → Faltam documentos`

Somente depois construir:

1. Fase 1 — Orientar documentação;
2. Documentação completa;
3. integração FAST MAIL → FAST PROC;
4. resposta de processo aberto;
5. demais procedimentos.

## Filosofia de interface

Mostrar somente o que exige decisão humana.

Automatizar silenciosamente:

- Bcc;
- leitura do operador;
- captura do e-mail;
- atualização interna;
- armazenamento de dados;
- formatação do assunto.

Evitar:

- status técnicos permanentes;
- botões redundantes;
- informações que não mudam a decisão do protocolista;
- card grande bloqueando o conteúdo do e-mail.
