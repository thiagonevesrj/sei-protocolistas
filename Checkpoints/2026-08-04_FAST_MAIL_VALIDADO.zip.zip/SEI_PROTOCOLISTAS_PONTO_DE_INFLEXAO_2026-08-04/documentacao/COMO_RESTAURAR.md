# Como restaurar este checkpoint

Copie somente os arquivos necessários da pasta `snapshot_atual` para:

`C:\Projetos\Sei-Protocolistas\sei-protocolistas`

Correspondência:

- `snapshot_atual\manifest.json`
  → `manifest.json`

- `snapshot_atual\cs_modules\fast_mail\index.js`
  → `cs_modules\fast_mail\index.js`

- `snapshot_atual\cs_modules\fast_mail\styles.css`
  → `cs_modules\fast_mail\styles.css`

- `snapshot_atual\data\catalogo-processos.json`
  → `data\catalogo-processos.json`

Não substitua pastas inteiras.

Depois:

1. feche todas as janelas do OWA;
2. abra `chrome://extensions`;
3. recarregue a extensão;
4. reabra o OWA;
5. teste primeiro uma resposta sem procedimento;
6. depois selecione Devolução de Taxas e teste a exigência.
