# Status funcional

## Validado

- [x] Manifest carrega no Chrome.
- [x] FAST MAIL autorizado no OWA.
- [x] Painel oculto na caixa de entrada.
- [x] Painel exibido na resposta.
- [x] Operador identificado.
- [x] E-mail atual capturado com segurança.
- [x] Bcc automático.
- [x] Bcc sem botão e sem quadro visual.
- [x] Catálogo carregado.
- [x] Card compacto.
- [x] Card recolhível.
- [x] Card movível.
- [x] Posição do card salva.
- [x] CPF opcional na triagem.
- [x] Procedimento opcional no primeiro contato.
- [x] Assunto com UNDEFINED.
- [x] Atualização posterior UNDEFINED → unidade.
- [x] Exigência DAF inserida no corpo.
- [x] Histórico preservado.
- [x] Divisor do histórico.
- [x] Link do formulário DAF funcional.

## Em validação editorial

- [ ] texto final da exigência;
- [ ] lista definitiva de checkboxes;
- [ ] linguagem institucional;
- [ ] assinatura final;
- [ ] comportamento quando a exigência já foi inserida.

## Ainda não construído

- [ ] Orientar documentação — Fase 1;
- [ ] Documentação completa;
- [ ] transferência ao FAST PROC;
- [ ] validação obrigatória do CPF no FAST PROC;
- [ ] retorno do número SEI;
- [ ] assunto FECHADO;
- [ ] resposta final;
- [ ] catálogo geral de formulários;
- [ ] demais procedimentos;
- [ ] ofícios de mero expediente;
- [ ] administração dos scripts.
